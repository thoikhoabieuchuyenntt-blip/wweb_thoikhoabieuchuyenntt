# TKB THPT Chuyên Nguyễn Thiện Thành — GitHub Pages

Bản này được xây dựng theo **đúng cấu trúc file `tbk1.xlsx`** đã cung cấp.

## 1. Website đọc Excel trực tiếp

Mở `index.html` rồi vào **Cập nhật dữ liệu** → chọn file `.xlsx` → **Tải Excel và cập nhật**.

Website nhận cấu trúc:
- `Thứ | Tiết | các cột lớp...`
- nhiều sheet
- sheet sáng/chiều
- ô Excel gộp
- nhiều dòng trong một ô
- nhiều giáo viên trong một ô
- lớp đội tuyển `11 (ĐT)`, `12 (ĐT)`
- Thứ 7 nếu có trong file.

Không yêu cầu các cột `Ngày/Buổi/Tiết/Lớp/Môn/Giáo viên`.

## 2. Đưa lên GitHub Pages

Upload toàn bộ thư mục này lên một repository GitHub.

Vào `Settings → Pages → Source → GitHub Actions`.

Workflow `update-tkb.yml` sẽ đọc `data/tkb.xlsx` bằng Python và tạo lại `data/schedule.json`.

## 3. Cập nhật cho toàn bộ người xem

Để toàn bộ người truy cập website thấy TKB mới:
1. Thay file `data/tkb.xlsx` trong repository bằng file Excel mới.
2. Commit.
3. GitHub Actions tự chạy parser.
4. Website được deploy lại.

Nút upload Excel trong trang web chỉ lưu dữ liệu trên **trình duyệt hiện tại**; GitHub Pages không cho JavaScript trên website tự ghi file vào repository nếu không có máy chủ/token.

## 4. Font

Toàn bộ giao diện dùng Times New Roman.
