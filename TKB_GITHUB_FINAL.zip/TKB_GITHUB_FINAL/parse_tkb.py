import json, re, os
from openpyxl import load_workbook

INPUT = os.path.join(os.path.dirname(__file__), '..', 'data', 'tkb.xlsx')
OUTPUT = os.path.join(os.path.dirname(__file__), '..', 'data', 'schedule.json')

def merge_map(ws):
    m = {}
    for rng in ws.merged_cells.ranges:
        min_col,min_row,max_col,max_row = rng.bounds
        top = ws.cell(min_row,min_col).value
        for r in range(min_row,max_row+1):
            for c in range(min_col,max_col+1):
                m[(r,c)] = top
    return m

def lines(v):
    if v is None: return []
    s = str(v).replace('\r\n','\n').replace('\r','\n').strip()
    return [x.strip() for x in s.split('\n') if x.strip()]

def parse_entry(line):
    if line == 'Chào cờ':
        return {'subject':'Chào cờ','teachers':[],'raw':line}
    if ' - ' in line:
        subject, rest = line.split(' - ',1)
        teachers=[x.strip() for x in rest.split(' - ') if x.strip()]
        return {'subject':subject.strip(),'teachers':teachers,'raw':line}
    if line.startswith('TA. '):
        return {'subject':'TA','teachers':[line[4:].strip()],'raw':line}
    return {'subject':line,'teachers':[],'raw':line}

def parse():
    wb = load_workbook(INPUT, data_only=True)
    entries=[]; classes=set(); teacher_display={}; sheets=[]; applied=set()
    for ws in wb.worksheets:
        mm=merge_map(ws); header=None
        for r in range(1,min(ws.max_row,30)+1):
            if str(ws.cell(r,1).value or '').strip()=='Thứ' and str(ws.cell(r,2).value or '').strip()=='Tiết':
                header=r; break
        if header is None: continue
        session='Chiều' if 'chiều' in ws.title.lower() else 'Sáng'
        app=None
        for r in range(1,min(header,5)+1):
            v=ws.cell(r,1).value
            if isinstance(v,str) and 'Áp dụng từ:' in v:
                app=v.strip(); applied.add(app)
        cols=[]
        for c in range(3,ws.max_column+1):
            v=mm.get((header,c),ws.cell(header,c).value)
            if v is None: continue
            name=str(v).strip()
            if not name or name=='Chủ nhiệm': continue
            cols.append((c,name)); classes.add(name)
        day=None; count=0
        for r in range(header+1,ws.max_row+1):
            dv=mm.get((r,1),ws.cell(r,1).value)
            if dv not in (None,''):
                try: day=int(float(dv))
                except: day=None
            pv=mm.get((r,2),ws.cell(r,2).value)
            try: period=int(float(pv))
            except: continue
            for c,cl in cols:
                for line in lines(mm.get((r,c),ws.cell(r,c).value)):
                    p=parse_entry(line)
                    for t in p['teachers']:
                        key=re.sub(r'\s+',' ',t).strip()
                        teacher_display.setdefault(key,t)
                    entries.append({'day':day,'session':session,'period':period,'class':cl,
                                    'subject':p['subject'],'teachers':p['teachers'],'raw':p['raw'],'sheet':ws.title})
                    count += 1
        sheets.append({'name':ws.title,'session':session,'classes':len(cols),'rows':ws.max_row,'applied':app})
    out={'entries':entries,'classes':sorted(classes),'teachers':sorted(teacher_display.values()),
         'meta':{'sheets':sheets,'applied':sorted(applied),'source':'data/tkb.xlsx'}}
    with open(OUTPUT,'w',encoding='utf-8') as f: json.dump(out,f,ensure_ascii=False,separators=(',',':'))
    print(f'Parsed {len(entries)} entries, {len(classes)} classes, {len(teacher_display)} teachers.')
if __name__=='__main__': parse()
